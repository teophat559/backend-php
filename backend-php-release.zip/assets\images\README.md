Put real default images here if needed:
- default-avatar.png
- default-banner.jpg
- default-contestant.jpg

These will be used only when a user/contestant has no uploaded image. In production, ensure you upload real assets or remove fallbacks from views.
