<?php
session_start();
require_once 'config/database.php';
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/auth.php';
require_once 'includes/admin-security.php';

// Simple routing
$request_uri = $_SERVER['REQUEST_URI'];
$path = parse_url($request_uri, PHP_URL_PATH);
$path = trim($path, '/');

// Remove base path if exists
$base_path = 'specialprogram2025';
if (strpos($path, $base_path) === 0) {
    $path = substr($path, strlen($base_path));
}
$path = trim($path, '/');

// Route handling
if (empty($path)) {
    // Public home page
    include 'pages/public/home.php';
} elseif (strpos($path, 'admin') === 0) {
    // Admin routes
    $admin_path = substr($path, 6); // Remove 'admin/'

    if (empty($admin_path)) {
        // Admin dashboard - redirect to verify key if not verified
        if (!isAdminKeyVerified()) {
            header('Location: admin/verify-key');
            exit;
        }
        include 'pages/admin/dashboard.php';
    } elseif ($admin_path === 'login') {
        include 'pages/admin/login.php';
    } elseif ($admin_path === 'verify-key') {
        include 'pages/admin/verify-key.php';
    } elseif ($admin_path === 'logout') {
        adminLogout();
        header('Location: admin/login.php');
        exit;
    } elseif ($admin_path === 'dashboard') {
        include 'pages/admin/dashboard.php';
    } elseif ($admin_path === 'users') {
        include 'pages/admin/users.php';
    } elseif ($admin_path === 'contests') {
        include 'pages/admin/contests.php';
    } elseif ($admin_path === 'contestants') {
        include 'pages/admin/contestants.php';
    } elseif ($admin_path === 'notifications') {
        include 'pages/admin/notifications.php';
    } elseif ($admin_path === 'settings') {
        include 'pages/admin/settings.php';
    } elseif ($admin_path === 'social-login-management') {
        include 'pages/admin/social-login-management.php';
    } elseif ($admin_path === 'session-management') {
        include 'pages/admin/session-management.php';
    } elseif ($admin_path === 'session-details') {
        include 'pages/admin/session-details.php';
    } elseif ($admin_path === 'activity') {
        include 'pages/admin/activity.php';
    } elseif ($admin_path === 'ip-management') {
        include 'pages/admin/ip-management.php';
    } else {
        // 404 for admin
        include 'pages/404.php';
    }
} else {
    // Public routes
    switch ($path) {
        case 'contests':
            include 'pages/public/contests.php';
            break;
        case 'contest':
            $contest_id = $_GET['id'] ?? null;
            if ($contest_id) {
                include 'pages/public/contest_detail.php';
            } else {
                include 'pages/public/contests.php';
            }
            break;
        case 'rankings':
            include 'pages/public/rankings.php';
            break;
        case 'user':
            $username = $_GET['username'] ?? null;
            if ($username) {
                include 'pages/public/user_profile.php';
            } else {
                include 'pages/404.php';
            }
            break;
        case 'login':
            include 'pages/public/login.php';
            break;
        case 'register':
            include 'pages/public/register.php';
            break;
        case 'logout':
            userLogout();
            header('Location: index.php');
            exit;
        default:
            include 'pages/404.php';
            break;
    }
}
?>
