<?php
/**
 * EMERGENCY ADMIN ACCESS
 * =====================
 * Use this file only in emergency situations
 * Delete this file after use for security
 */

session_start();
require_once 'config/database.php';
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/admin-security.php';

// Emergency key (change this!)
$EMERGENCY_KEY = 'EMERGENCY_ACCESS_2025';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = $_POST['emergency_key'] ?? '';

    if ($key === $EMERGENCY_KEY) {
        $_SESSION['admin_key_verified'] = true;
        $_SESSION['admin_key_time'] = time();
        $_SESSION['emergency_access'] = true;

        header('Location: ' . APP_URL . '/admin/dashboard');
        exit;
    } else {
        $error = 'Emergency key không đúng!';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Emergency Admin Access</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 50px; }
        .container { max-width: 400px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .warning { background: #ff4444; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #ff4444; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #cc0000; }
    </style>
</head>
<body>
    <div class="container">
        <div class="warning">
            <strong>⚠️ EMERGENCY ACCESS ONLY ⚠️</strong><br>
            Chỉ sử dụng trong trường hợp khẩn cấp!
        </div>

        <h2>Emergency Admin Access</h2>

        <?php if (isset($error)): ?>
            <div style="color: red; margin: 10px 0;"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Emergency Key:</label>
            <input type="password" name="emergency_key" required>
            <button type="submit">Access Admin</button>
        </form>

        <p style="font-size: 12px; color: #666; margin-top: 20px;">
            <strong>Lưu ý:</strong> Xóa file này sau khi sử dụng để bảo mật!
        </p>
    </div>
</body>
</html>
