#!/bin/bash

# DEPLOY ADMIN SECURITY SYSTEM
# ============================
# Script này sẽ triển khai hệ thống bảo mật 2 lớp cho admin

set -e

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Function to print status
print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Configuration
DOMAIN="specialprogram2025.online"
DB_NAME="specialprogram2025"
DB_USER="specialprogram"
DB_PASS="123123zz@"
WEB_ROOT="/var/www/html/horizons-voting/php-version"

print_status "Bắt đầu triển khai Admin Security System..."
print_status "Domain: $DOMAIN"
print_status "Database: $DB_NAME"

# 1. Update database with security tables
print_status "Cập nhật database với bảng bảo mật..."
mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" < "$WEB_ROOT/update-admin-security.sql"
print_success "Database đã được cập nhật"

# 2. Set proper permissions
print_status "Thiết lập quyền file..."
chmod 644 "$WEB_ROOT/includes/admin-security.php"
chmod 644 "$WEB_ROOT/pages/admin/verify-key.php"
chmod 644 "$WEB_ROOT/admin/verify-key.php"
chmod 644 "$WEB_ROOT/update-admin-security.sql"

# 3. Create admin key file (for emergency access)
print_status "Tạo file admin key backup..."
ADMIN_KEY_FILE="$WEB_ROOT/admin-key-backup.txt"
echo "ADMIN SECURITY KEY: SP2025_ADMIN_SECURE_KEY_2025" > "$ADMIN_KEY_FILE"
echo "Generated: $(date)" >> "$ADMIN_KEY_FILE"
echo "Domain: $DOMAIN" >> "$ADMIN_KEY_FILE"
echo "" >> "$ADMIN_KEY_FILE"
echo "IMPORTANT: Keep this file secure!" >> "$ADMIN_KEY_FILE"
echo "This key is required to access admin panel." >> "$ADMIN_KEY_FILE"
chmod 600 "$ADMIN_KEY_FILE"
print_success "Admin key backup đã được tạo: $ADMIN_KEY_FILE"

# 4. Test admin security
print_status "Kiểm tra hệ thống bảo mật..."
if [ -f "$WEB_ROOT/includes/admin-security.php" ]; then
    print_success "Admin security file exists"
else
    print_error "Admin security file missing!"
    exit 1
fi

if [ -f "$WEB_ROOT/pages/admin/verify-key.php" ]; then
    print_success "Admin verify key page exists"
else
    print_error "Admin verify key page missing!"
    exit 1
fi

# 5. Create security log directory
print_status "Tạo thư mục log bảo mật..."
mkdir -p "$WEB_ROOT/logs/security"
chmod 755 "$WEB_ROOT/logs/security"
touch "$WEB_ROOT/logs/security/admin-access.log"
chmod 644 "$WEB_ROOT/logs/security/admin-access.log"

# 6. Update .htaccess for security
print_status "Cập nhật .htaccess cho bảo mật..."
cat >> "$WEB_ROOT/.htaccess" << 'EOF'

# Admin Security Headers
<IfModule mod_headers.c>
    # Security headers for admin area
    <LocationMatch "^/admin">
        Header always set X-Frame-Options "DENY"
        Header always set X-Content-Type-Options "nosniff"
        Header always set X-XSS-Protection "1; mode=block"
        Header always set Referrer-Policy "strict-origin-when-cross-origin"
        Header always set Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline' https://cdn.tailwindcss.com https://code.jquery.com https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://cdnjs.cloudflare.com; img-src 'self' data: https:; font-src 'self' https://cdnjs.cloudflare.com;"
    </LocationMatch>
</IfModule>

# Block access to admin key backup
<Files "admin-key-backup.txt">
    Order allow,deny
    Deny from all
</Files>

# Block access to security files
<FilesMatch "\.(key|pem|crt|log)$">
    Order allow,deny
    Deny from all
</FilesMatch>
EOF

print_success ".htaccess đã được cập nhật"

# 7. Create emergency access script
print_status "Tạo script emergency access..."
cat > "$WEB_ROOT/emergency-admin-access.php" << 'EOF'
<?php
/**
 * EMERGENCY ADMIN ACCESS
 * =====================
 * Use this file only in emergency situations
 * Delete this file after use for security
 */

session_start();
require_once 'config/database.php';
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/admin-security.php';

// Emergency key (change this!)
$EMERGENCY_KEY = 'EMERGENCY_ACCESS_2025';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = $_POST['emergency_key'] ?? '';

    if ($key === $EMERGENCY_KEY) {
        $_SESSION['admin_key_verified'] = true;
        $_SESSION['admin_key_time'] = time();
        $_SESSION['emergency_access'] = true;

        header('Location: ' . APP_URL . '/admin/dashboard');
        exit;
    } else {
        $error = 'Emergency key không đúng!';
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Emergency Admin Access</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f0f0f0; padding: 50px; }
        .container { max-width: 400px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        .warning { background: #ff4444; color: white; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        input[type="password"] { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 5px; }
        button { width: 100%; padding: 10px; background: #ff4444; color: white; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #cc0000; }
    </style>
</head>
<body>
    <div class="container">
        <div class="warning">
            <strong>⚠️ EMERGENCY ACCESS ONLY ⚠️</strong><br>
            Chỉ sử dụng trong trường hợp khẩn cấp!
        </div>

        <h2>Emergency Admin Access</h2>

        <?php if (isset($error)): ?>
            <div style="color: red; margin: 10px 0;"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <label>Emergency Key:</label>
            <input type="password" name="emergency_key" required>
            <button type="submit">Access Admin</button>
        </form>

        <p style="font-size: 12px; color: #666; margin-top: 20px;">
            <strong>Lưu ý:</strong> Xóa file này sau khi sử dụng để bảo mật!
        </p>
    </div>
</body>
</html>
EOF

chmod 600 "$WEB_ROOT/emergency-admin-access.php"
print_success "Emergency access script đã được tạo"

# 8. Final verification
print_status "Kiểm tra cuối cùng..."

# Test database connection
if mysql -u"$DB_USER" -p"$DB_PASS" "$DB_NAME" -e "SELECT COUNT(*) FROM admin_access_log;" > /dev/null 2>&1; then
    print_success "Database connection OK"
else
    print_error "Database connection failed!"
    exit 1
fi

# Test file permissions
if [ -r "$WEB_ROOT/includes/admin-security.php" ]; then
    print_success "File permissions OK"
else
    print_error "File permissions issue!"
    exit 1
fi

print_success "=========================================="
print_success "ADMIN SECURITY SYSTEM DEPLOYED SUCCESSFULLY!"
print_success "=========================================="
print_status ""
print_status "🔐 ADMIN SECURITY KEY: SP2025_ADMIN_SECURE_KEY_2025"
print_status ""
print_status "📋 ACCESS FLOW:"
print_status "   1. Visit: https://$DOMAIN/admin"
print_status "   2. Enter admin key: SP2025_ADMIN_SECURE_KEY_2025"
print_status "   3. Direct access to admin dashboard"
print_status ""
print_status "🚨 EMERGENCY ACCESS:"
print_status "   https://$DOMAIN/emergency-admin-access.php"
print_status ""
print_status "📁 SECURITY FILES:"
print_status "   - Admin Key Backup: $ADMIN_KEY_FILE"
print_status "   - Emergency Access: $WEB_ROOT/emergency-admin-access.php"
print_status ""
print_status "🔒 SECURITY FEATURES:"
print_status "   - Single-layer authentication (Admin Key only)"
print_status "   - IP blocking after 5 failed attempts"
print_status "   - Access logging and monitoring"
print_status "   - 24-hour key expiration"
print_status "   - Brute force protection"
print_status ""
print_warning "⚠️  IMPORTANT: Delete emergency-admin-access.php after first use!"
print_success "✅ Admin Security System ready!"
